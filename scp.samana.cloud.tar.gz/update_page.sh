docker cp frontend/src/src/router/. frontend_node:/app/src/router/
docker cp frontend/src/src/views/. frontend_node:/app/src/views/
docker cp frontend/src/src/utils/. frontend_node:/app/src/utils/
docker cp frontend/src/src/layout/. frontend_node:/app/src/layout/
docker cp frontend/src/src/App.vue frontend_node:/app/src/
docker cp frontend/src/index.html frontend_node:/app/
docker cp frontend/src/src/service/. frontend_node:/app/src/service/
docker cp frontend/src/public/. frontend_node:/app/public/



