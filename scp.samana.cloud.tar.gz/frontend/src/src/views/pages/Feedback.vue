<template>
    <div className="card">
        <h5>Application</h5>
        <p>Use this page to start from scratch and place your custom content.</p>
    </div>
</template>
 