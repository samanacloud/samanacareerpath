<template>
  <div className="card">
      <h5>Jobs Offers</h5>
      <p>Use this page to start from scratch and place your custom content.</p>
  </div>
</template>
